import tkinter as tk
from tkinter import messagebox
import re

tasks = []

# Parse time input like "1h 2m 30s" → seconds
def parse_time(time_str):
    time_str = time_str.lower().replace(" ", "")
    total_seconds = 0
    matches = re.findall(r"(\d+)(h|m|s)", time_str)
    for value, unit in matches:
        if unit == 'h':
            total_seconds += int(value) * 3600
        elif unit == 'm':
            total_seconds += int(value) * 60
        elif unit == 's':
            total_seconds += int(value)
    return total_seconds if total_seconds > 0 else None

# Ask user for task completion status
def ask_status(task_index):
    task_name = tasks[task_index]["text"]
    response = messagebox.askyesno("Time's Up", f"Is your work completed?\n\n📝 {task_name}")
    if response:
        tasks[task_index]["status"] = "Completed"
        tasks[task_index]["icon"] = "✅"
    else:
        tasks[task_index]["status"] = "Pending"
        tasks[task_index]["icon"] = "❌"
    render_tasks()

# Timer countdown
def countdown(task_index, label):
    if task_index >= len(tasks): return
    task = tasks[task_index]
    seconds = task["time_left"]

    if seconds > 0:
        mins = seconds // 60
        secs = seconds % 60
        label.config(text=f"{mins:02d}:{secs:02d}", fg="green")
        task["time_left"] -= 1
        label.after(1000, countdown, task_index, label)
    else:
        label.config(text="⏰ TIME'S UP!", fg="red")
        if not task["notified"]:
            task["notified"] = True
            ask_status(task_index)

# Validate task name contains only alphabets
def is_valid_task_name(name):
    return name.replace(" ", "").isalpha()

# Add new task
def add_task():
    task_text = task_entry.get().strip()
    time_input = time_entry.get().strip()

    if not task_text or not is_valid_task_name(task_text):
        time_label.config(text="Task must contain only letters (A-Z)", fg="red")
        return

    seconds = parse_time(time_input)
    if seconds is None:
        time_label.config(text="Use format like 1h 2m 30s", fg="red")
        return
    else:
        time_label.config(text="")

    task_data = {
        "text": task_text,
        "time_left": seconds,
        "notified": False,
        "status": "",
        "icon": ""
    }
    tasks.append(task_data)
    render_tasks()
    task_entry.delete(0, tk.END)
    time_entry.delete(0, tk.END)

# Delete one task
def delete_task(index):
    if 0 <= index < len(tasks):
        del tasks[index]
        render_tasks()

# Delete all tasks
def clear_all_tasks():
    if messagebox.askyesno("Confirm", "Are you sure you want to clear all tasks?"):
        tasks.clear()
        render_tasks()

# Display all tasks
def render_tasks():
    for widget in task_frame.winfo_children():
        widget.destroy()

    for i, task in enumerate(tasks):
        frame = tk.Frame(task_frame, bg="white", pady=3)
        frame.pack(fill="x", pady=1)

        icon_label = tk.Label(frame, text=task["icon"], font=("Arial", 14), width=3)
        icon_label.pack(side="left", padx=5)

        label_text = tk.Label(frame, text=task["text"], font=("Arial", 12), anchor="w", width=25)
        label_text.pack(side="left")

        time_display = tk.Label(frame, text="", font=("Arial", 12), fg="green", width=12)
        time_display.pack(side="left", padx=10)

        status_label = tk.Label(frame, text=task["status"], font=("Arial", 11), width=10)
        status_label.pack(side="left", padx=5)

        del_btn = tk.Button(frame, text="Delete", font=("Arial", 10), bg="#ff4d4d", fg="white",
                            command=lambda idx=i: delete_task(idx))
        del_btn.pack(side="right", padx=10)

        if not task["notified"]:
            countdown(i, time_display)
        else:
            if task["status"] == "Completed":
                time_display.config(text="✅ Completed", fg="green")
            elif task["status"] == "Pending":
                time_display.config(text="❌ Pending", fg="red")

# --- GUI Setup ---
window = tk.Tk()
window.title("⏳ Smart To-Do Tracker")
window.geometry("730x600")
window.configure(bg="#eaf6f6")

tk.Label(window, text="📝 TickTask", font=("Helvetica", 20, "bold"), bg="#eaf6f6").pack(pady=10)

# Input frame
input_frame = tk.Frame(window, bg="#eaf6f6")
input_frame.pack(pady=10)

task_entry = tk.Entry(input_frame, font=("Arial", 14), width=30)
task_entry.grid(row=0, column=0, padx=5)

time_entry = tk.Entry(input_frame, font=("Arial", 14), width=15)
time_entry.grid(row=0, column=1, padx=5)
time_entry.insert(0, "2m")

add_btn = tk.Button(input_frame, text="Add Task ⏳", font=("Arial", 12), bg="#90ee90", command=add_task)
add_btn.grid(row=0, column=2, padx=5)

clear_btn = tk.Button(window, text="🧹 Clear All Tasks", font=("Arial", 12), bg="tomato", fg="white", command=clear_all_tasks)
clear_btn.pack(pady=5)

time_label = tk.Label(window, text="Format: 1h 2m 30s or 3m 5s | Task: only letters", font=("Arial", 10), fg="gray", bg="#eaf6f6")
time_label.pack()

# Tasks area
task_frame = tk.Frame(window, bg="white", bd=2, relief="groove")
task_frame.pack(pady=15, padx=10, fill="both", expand=True)

window.mainloop()


