import tkinter as tk
from tkinter import ttk, messagebox
from tkcalendar import DateEntry
from datetime import datetime, timedelta
import json
import os
import logging
from pathlib import Path
from typing import List, Dict, Optional

# --- Constants ---
CONFIG_FILE = "task_scheduler_config.json"
DATA_FILE = "tasks.json"
DEFAULT_CHECK_INTERVAL = 10000  # 10 seconds
TASK_CATEGORIES = ["Work", "Personal", "Study", "Health", "Other"]
TASK_PRIORITIES = ["🔥 High", "🔼 Medium", "🔽 Low"]
PRIORITY_COLORS = {
    "🔥 High": "#ffcccc",
    "🔼 Medium": "#ffffcc",
    "🔽 Low": "#e6ffe6"
}

# --- Logging Setup ---
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("task_scheduler.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class Task:
    """Class representing a single task with 24-hour time support"""
    def __init__(self, name: str, date: datetime.date, start: datetime.time, 
                 end: datetime.time, category: str = "Other", priority: str = "🔼 Medium"):
        self.name = name
        self.date = date
        self.start = start
        self.end = end
        self.category = category
        self.priority = priority
        self.notified = False
        self.status = "⏳ Scheduled"
        self.created_at = datetime.now()
        self.validate()
    
    def validate(self):
        """Validate task parameters with 24-hour support"""
        if not self.name or len(self.name.strip()) < 2:
            raise ValueError("Task name must be at least 2 characters")
            
        # Convert times to datetime for proper comparison (handling overnight tasks)
        start_dt = datetime.combine(self.date, self.start)
        end_dt = datetime.combine(self.date, self.end)
        
        # Handle overnight tasks (end time is next day)
        if self.end <= self.start:
            end_dt += timedelta(days=1)
        
        if end_dt <= start_dt:
            raise ValueError("End time must be after start time")
            
        if end_dt < datetime.now():
            raise ValueError("Cannot create tasks that end in the past")
            
        if self.category not in TASK_CATEGORIES:
            raise ValueError("Invalid category")
        if self.priority not in TASK_PRIORITIES:
            raise ValueError("Invalid priority")
    
    def to_dict(self) -> Dict:
        """Convert task to dictionary for serialization"""
        return {
            "name": self.name,
            "date": self.date.strftime("%Y-%m-%d"),
            "start": self.start.strftime("%H:%M"),
            "end": self.end.strftime("%H:%M"),
            "category": self.category,
            "priority": self.priority,
            "notified": self.notified,
            "status": self.status,
            "created_at": self.created_at.strftime("%Y-%m-%d %H:%M:%S")
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Task':
        """Create Task from dictionary"""
        task = cls(
            name=data["name"],
            date=datetime.strptime(data["date"], "%Y-%m-%d").date(),
            start=datetime.strptime(data["start"], "%H:%M").time(),
            end=datetime.strptime(data["end"], "%H:%M").time(),
            category=data.get("category", "Other"),
            priority=data.get("priority", "🔼 Medium")
        )
        task.notified = data.get("notified", False)
        task.status = data.get("status", "⏳ Scheduled")
        task.created_at = datetime.strptime(data["created_at"], "%Y-%m-%d %H:%M:%S")
        return task
    
    def is_active(self, when: datetime = None) -> bool:
        """Check if task is active at given time (defaults to now)"""
        when = when or datetime.now()
        start_dt = datetime.combine(self.date, self.start)
        end_dt = datetime.combine(self.date, self.end)
        
        # Handle overnight tasks
        if self.end <= self.start:
            end_dt += timedelta(days=1)
            
        return start_dt <= when <= end_dt
    
    def get_time_range_str(self) -> str:
        """Get formatted time range string with overnight indicator"""
        time_str = f"{self.start.strftime('%H:%M')} - {self.end.strftime('%H:%M')}"
        if self.end <= self.start:
            time_str += " (overnight)"
        return time_str

class TaskManager:
    """Core task management logic with persistence"""
    def __init__(self):
        self.tasks: List[Task] = []
        self.load_tasks()
    
    def add_task(self, task: Task):
        """Add a new task with validation"""
        try:
            task.validate()
            self.tasks.append(task)
            self.save_tasks()
            logger.info(f"Added task: {task.name}")
            return True
        except ValueError as e:
            logger.warning(f"Failed to add task: {str(e)}")
            raise
    
    def delete_task(self, index: int):
        """Remove a task by index"""
        if 0 <= index < len(self.tasks):
            task = self.tasks.pop(index)
            self.save_tasks()
            logger.info(f"Deleted task: {task.name}")
            return True
        return False
    
    def clear_all_tasks(self):
        """Remove all tasks"""
        self.tasks.clear()
        self.save_tasks()
        logger.info("Cleared all tasks")
    
    def mark_completed(self, index: int, completed: bool):
        """Update task completion status"""
        if 0 <= index < len(self.tasks):
            self.tasks[index].status = "✅ Completed" if completed else "❌ Pending"
            self.tasks[index].notified = True
            self.save_tasks()
            logger.info(f"Marked task {self.tasks[index].name} as {self.tasks[index].status}")
    
    def check_scheduled_tasks(self):
        """Check for tasks that need notification with 24-hour support"""
        now = datetime.now()
        for task in self.tasks:
            if not task.notified:
                start_dt = datetime.combine(task.date, task.start)
                end_dt = datetime.combine(task.date, task.end)
                
                # Handle overnight tasks
                if task.end <= task.start:
                    end_dt += timedelta(days=1)
                
                if now > end_dt:
                    task.notified = True
                    self.save_tasks()
                    return task
        return None
    
    def save_tasks(self):
        """Save tasks to file"""
        try:
            with open(DATA_FILE, "w") as f:
                json.dump([task.to_dict() for task in self.tasks], f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save tasks: {str(e)}")
    
    def load_tasks(self):
        """Load tasks from file"""
        try:
            if os.path.exists(DATA_FILE):
                with open(DATA_FILE, "r") as f:
                    data = json.load(f)
                    self.tasks = [Task.from_dict(item) for item in data]
                logger.info(f"Loaded {len(self.tasks)} tasks from storage")
        except Exception as e:
            logger.error(f"Failed to load tasks: {str(e)}")
            self.tasks = []

class TaskSchedulerUI:
    """Main application GUI with enhanced features"""
    def __init__(self, root: tk.Tk, task_manager: TaskManager):
        self.root = root
        self.task_manager = task_manager
        self.setup_ui()
        self.schedule_task_check()
        self.setup_context_menu()
    
    def setup_context_menu(self):
        """Initialize right-click context menu"""
        self.context_menu = tk.Menu(self.root, tearoff=0)
        self.context_menu.add_command(label="Delete Task", command=self.delete_selected_task)
        self.context_menu.add_command(label="Mark Completed", command=lambda: self.mark_task_status(True))
        self.context_menu.add_command(label="Mark Pending", command=lambda: self.mark_task_status(False))
        self.tree.bind("<Button-3>", self.show_context_menu)
    
    def show_context_menu(self, event):
        """Display context menu on right-click"""
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)
            self.context_menu.post(event.x_root, event.y_root)
    
    def mark_task_status(self, completed: bool):
        """Mark selected task as completed/pending"""
        selection = self.tree.selection()
        if selection:
            index = self.tree.index(selection[0])
            self.task_manager.mark_completed(index, completed)
            self.refresh_task_list()
    
    def setup_ui(self):
        """Initialize all UI components with enhanced features"""
        self.root.title("🚀Task Scheduler")
        self.root.geometry("1100x750")
        self.root.configure(bg="#f5f7fa")
        
        # Style configuration with priority-based colors
        self.style = ttk.Style()
        self.style.configure("TFrame", background="#f5f7fa")
        self.style.configure("TLabel", background="#f5f7fa", font=("Segoe UI", 10))
        self.style.configure("TButton", font=("Segoe UI", 10))
        self.style.configure("Header.TLabel", font=("Segoe UI", 16, "bold"))
        
        # Header
        header_frame = ttk.Frame(self.root)
        header_frame.pack(pady=10, padx=10, fill="x")
        ttk.Label(header_frame, text="🚀TickTask", style="Header.TLabel").pack(side="left")
        
        # Input Section
        input_frame = ttk.Frame(self.root, padding=10)
        input_frame.pack(fill="x", padx=10, pady=5)
        
        # Task Name
        ttk.Label(input_frame, text="Task Name:").grid(row=0, column=0, sticky="w")
        self.task_entry = ttk.Entry(input_frame, font=("Segoe UI", 12), width=25)
        self.task_entry.grid(row=1, column=0, padx=5, sticky="w")
        
        # Date
        ttk.Label(input_frame, text="Date:").grid(row=0, column=1, sticky="w")
        self.calendar = DateEntry(input_frame, font=("Segoe UI", 12), width=12)
        self.calendar.grid(row=1, column=1, padx=5, sticky="w")
        
        # Start Time
        ttk.Label(input_frame, text="Start Time (HH:MM):").grid(row=0, column=2, sticky="w")
        self.start_time = ttk.Entry(input_frame, font=("Segoe UI", 12), width=7)
        self.start_time.grid(row=1, column=2, padx=5, sticky="w")
        self.start_time.insert(0, "00:00")
        
        # End Time
        ttk.Label(input_frame, text="End Time (HH:MM):").grid(row=0, column=3, sticky="w")
        self.end_time = ttk.Entry(input_frame, font=("Segoe UI", 12), width=7)
        self.end_time.grid(row=1, column=3, padx=5, sticky="w")
        self.end_time.insert(0, "01:00")
        
        # 24-hour format note
        ttk.Label(input_frame, text="24-hour format", foreground="gray", font=("Segoe UI", 8)).grid(row=2, column=2, columnspan=2, sticky="w")
        
        # Category
        ttk.Label(input_frame, text="Category:").grid(row=0, column=4, sticky="w")
        self.category_var = tk.StringVar(value=TASK_CATEGORIES[0])
        self.category_menu = ttk.Combobox(input_frame, textvariable=self.category_var, 
                                        values=TASK_CATEGORIES, state="readonly", width=10)
        self.category_menu.grid(row=1, column=4, padx=5, sticky="w")
        
        # Priority
        ttk.Label(input_frame, text="Priority:").grid(row=0, column=5, sticky="w")
        self.priority_var = tk.StringVar(value=TASK_PRIORITIES[1])
        self.priority_menu = ttk.Combobox(input_frame, textvariable=self.priority_var, 
                                         values=TASK_PRIORITIES, state="readonly", width=10)
        self.priority_menu.grid(row=1, column=5, padx=5, sticky="w")
        
        # Add Button
        self.add_btn = ttk.Button(input_frame, text="Add Task", command=self.add_task)
        self.add_btn.grid(row=1, column=6, padx=10)
        
        # Clear Button
        self.clear_btn = ttk.Button(input_frame, text="Clear All", command=self.clear_all_tasks)
        self.clear_btn.grid(row=1, column=7, padx=5)
        
        # Sort Button
        self.sort_btn = ttk.Button(input_frame, text="Sort by Priority", command=self.sort_by_priority)
        self.sort_btn.grid(row=1, column=8, padx=5)
        
        # Feedback Label
        self.feedback_label = ttk.Label(input_frame, text="Enter task details (24-hour format)", foreground="gray")
        self.feedback_label.grid(row=2, column=0, columnspan=9, pady=5, sticky="w")
        
        # Task List Container
        list_container = ttk.Frame(self.root)
        list_container.pack(fill="both", expand=True, padx=10, pady=5)
        
        # Treeview with Scrollbar
        self.tree = ttk.Treeview(list_container, columns=("name", "date", "time", "category", "priority", "status"), 
                                show="headings", selectmode="browse")
        
        # Configure columns
        self.tree.heading("name", text="Task Name", anchor="w")
        self.tree.heading("date", text="Date", anchor="w")
        self.tree.heading("time", text="Time", anchor="w")
        self.tree.heading("category", text="Category", anchor="w")
        self.tree.heading("priority", text="Priority", anchor="w")
        self.tree.heading("status", text="Status", anchor="w")
        
        self.tree.column("name", width=200, anchor="w")
        self.tree.column("date", width=100, anchor="w")
        self.tree.column("time", width=150, anchor="w")
        self.tree.column("category", width=100, anchor="w")
        self.tree.column("priority", width=100, anchor="w")
        self.tree.column("status", width=120, anchor="w")
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(list_container, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        
        # Layout
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Configure tag colors for priorities
        for priority, color in PRIORITY_COLORS.items():
            self.tree.tag_configure(priority, background=color)
        
        # Delete Button
        self.delete_btn = ttk.Button(self.root, text="Delete Selected", command=self.delete_selected_task)
        self.delete_btn.pack(pady=5)
        
        # Status Bar
        self.status_var = tk.StringVar(value=f"Tasks: {len(self.task_manager.tasks)} | Ready")
        self.status_bar = ttk.Label(self.root, textvariable=self.status_var, relief="sunken")
        self.status_bar.pack(fill="x", padx=10, pady=5)
        
        # Load initial tasks
        self.refresh_task_list()
    
    def sort_by_priority(self):
        """Sort tasks by priority (High > Medium > Low)"""
        priority_order = {"🔥 High": 0, "🔼 Medium": 1, "🔽 Low": 2}
        self.task_manager.tasks.sort(key=lambda x: priority_order[x.priority])
        self.task_manager.save_tasks()
        self.refresh_task_list()
        self.feedback_label.config(text="Tasks sorted by priority", foreground="green")
    
    def refresh_task_list(self):
        """Update the task list display with priority-based coloring"""
        self.tree.delete(*self.tree.get_children())
        for task in self.task_manager.tasks:
            self.tree.insert("", "end", values=(
                task.name,
                task.date.strftime("%d-%b-%Y"),
                task.get_time_range_str(),
                task.category,
                task.priority,
                task.status
            ), tags=(task.priority,))
        self.status_var.set(f"Tasks: {len(self.task_manager.tasks)} | Last update: {datetime.now().strftime('%H:%M:%S')}")
    
    def add_task(self):
        """Handle new task creation with 24-hour support"""
        name = self.task_entry.get().strip()
        date = self.calendar.get_date()
        start_str = self.start_time.get()
        end_str = self.end_time.get()
        category = self.category_var.get()
        priority = self.priority_var.get()
        
        try:
            # Validate time format
            datetime.strptime(start_str, "%H:%M")
            datetime.strptime(end_str, "%H:%M")
            
            start = datetime.strptime(start_str, "%H:%M").time()
            end = datetime.strptime(end_str, "%H:%M").time()
            
            # Check for overnight tasks
            if end <= start:
                response = messagebox.askyesno(
                    "Overnight Task", 
                    "This task spans midnight. Is this intentional?\n\n"
                    f"Task will run from {start_str} to {end_str} (next day)"
                )
                if not response:
                    self.feedback_label.config(text="Task creation cancelled", foreground="orange")
                    return
            
            task = Task(
                name=name,
                date=date,
                start=start,
                end=end,
                category=category,
                priority=priority
            )
            
            if self.task_manager.add_task(task):
                self.task_entry.delete(0, tk.END)
                self.start_time.delete(0, tk.END)
                self.start_time.insert(0, "00:00")
                self.end_time.delete(0, tk.END)
                self.end_time.insert(0, "01:00")
                self.feedback_label.config(text="Task added successfully", foreground="green")
                self.refresh_task_list()
        
        except ValueError as e:
            self.feedback_label.config(text=f"Invalid time format or {str(e)}", foreground="red")
            logger.warning(f"Validation error: {str(e)}")
        except Exception as e:
            self.feedback_label.config(text="An error occurred", foreground="red")
            logger.error(f"Error adding task: {str(e)}")
    
    def delete_selected_task(self):
        """Delete the currently selected task"""
        selection = self.tree.selection()
        if selection:
            index = self.tree.index(selection[0])
            if self.task_manager.delete_task(index):
                self.refresh_task_list()
                self.feedback_label.config(text="Task deleted", foreground="green")
            else:
                self.feedback_label.config(text="Failed to delete task", foreground="red")
        else:
            self.feedback_label.config(text="No task selected", foreground="orange")
    
    def clear_all_tasks(self):
        """Confirm and clear all tasks"""
        if messagebox.askyesno("Confirm Clear", "Delete all tasks? This cannot be undone."):
            self.task_manager.clear_all_tasks()
            self.refresh_task_list()
            self.feedback_label.config(text="All tasks cleared", foreground="green")
    
    def show_notification(self, task: Task):
        """Show task completion dialog with overnight info"""
        time_info = task.get_time_range_str()
        response = messagebox.askyesno(
            "Task Completed?",
            f"🕒 Time's up for task: {task.name}\n\n"
            f"📅 Date: {task.date.strftime('%d %b %Y')}\n"
            f"⏰ Time: {time_info}\n"
            f"🏷️ Priority: {task.priority}\n\n"
            "Was this task completed?"
        )
        
        index = self.task_manager.tasks.index(task)
        self.task_manager.mark_completed(index, response)
        self.refresh_task_list()
    
    def schedule_task_check(self):
        """Periodically check for tasks needing notification"""
        task = self.task_manager.check_scheduled_tasks()
        if task:
            self.show_notification(task)
        self.root.after(DEFAULT_CHECK_INTERVAL, self.schedule_task_check)

def main():
    """Application entry point"""
    try:
        # Initialize task manager
        task_manager = TaskManager()
        
        # Create main window
        root = tk.Tk()
        
        # Set window icon if available
        try:
            root.iconbitmap("task_icon.ico")
        except:
            pass
        
        # Initialize UI
        app = TaskSchedulerUI(root, task_manager)
        
        # Start main loop
        root.mainloop()
    
    except Exception as e:
        logger.critical(f"Application error: {str(e)}")
        messagebox.showerror("Critical Error", f"The application encountered an error:\n\n{str(e)}")

if __name__ == "__main__":
    main()