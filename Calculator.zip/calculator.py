import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import json
import os
import math

# Constants
HISTORY_FILE = "calc_history.json"
CONFIG_FILE = "calc_config.json"
THEMES = {
    "clam": {"name": "Clam", "bg": "#f0f0f0", "fg": "#333", "highlight": "#4CAF50"},
    "alt": {"name": "Alternative", "bg": "#f0f0f0", "fg": "#333", "highlight": "#4CAF50"},
    "default": {"name": "Default", "bg": "#f0f0f0", "fg": "#333", "highlight": "#4CAF50"}
}

class CalculatorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("🧮Calculator")
        self.root.geometry("600x700")
        self.current_theme = "clam"
        self.history = []
        
        self.load_config()
        self.setup_ui()
        self.load_history()
        self.bind_events()
    
    def setup_ui(self):
        self.apply_theme()
        
        # Main container
        self.main_frame = ttk.Frame(self.root, padding=10)
        self.main_frame.pack(expand=True, fill=tk.BOTH)
        
        # Title
        self.title_label = ttk.Label(
            self.main_frame, 
            text="Enhanced Calculator", 
            font=("Helvetica", 20, "bold")
        )
        self.title_label.pack(pady=10)
        
        # Input Section
        self.create_input_section()
        
        # Result Display
        self.create_result_section()
        
        # History Section
        self.create_history_section()
        
        # Menu
        self.setup_menu()
    
    def create_input_section(self):
        input_frame = ttk.LabelFrame(self.main_frame, text="Input", padding=10)
        input_frame.pack(fill=tk.X, pady=5)
        
        # First number
        ttk.Label(input_frame, text="First Number:", font=("Arial", 12)).grid(row=0, column=0, sticky="w", padx=5, pady=5)
        self.entry1 = ttk.Entry(input_frame, font=("Arial", 14), width=20)
        self.entry1.grid(row=1, column=0, padx=5, pady=5, columnspan=2, sticky="ew")
        self.entry1.focus()
        
        # Second number
        ttk.Label(input_frame, text="Second Number:", font=("Arial", 12)).grid(row=2, column=0, sticky="w", padx=5, pady=5)
        self.entry2 = ttk.Entry(input_frame, font=("Arial", 14), width=20)
        self.entry2.grid(row=3, column=0, padx=5, pady=5, columnspan=2, sticky="ew")
        
        # Operator
        ttk.Label(input_frame, text="Operation:", font=("Arial", 12)).grid(row=4, column=0, sticky="w", padx=5, pady=5)
        self.operator = tk.StringVar(value="+")
        operators = ["+", "-", "*", "/", "√", "x^y", "log", "sin", "cos", "tan"]
        self.op_menu = ttk.Combobox(
            input_frame, 
            textvariable=self.operator, 
            values=operators,
            font=("Arial", 12),
            state="readonly",
            width=12
        )
        self.op_menu.grid(row=5, column=0, pady=5, padx=5, sticky="w")
        
        # Buttons Frame
        btn_frame = ttk.Frame(input_frame)
        btn_frame.grid(row=6, column=0, columnspan=2, pady=10, sticky="ew")
        
        ttk.Button(
            btn_frame, text="Calculate", 
            command=self.calculate
        ).pack(side=tk.LEFT, expand=True, padx=5, ipady=5)
        
        ttk.Button(
            btn_frame, text="Clear", 
            command=self.clear_fields
        ).pack(side=tk.LEFT, expand=True, padx=5, ipady=5)
    
    def create_result_section(self):
        result_frame = ttk.Frame(self.main_frame)
        result_frame.pack(fill=tk.X, pady=10)
        
        self.result_label = ttk.Label(
            result_frame, 
            text="Result: ", 
            font=("Arial", 16), 
            foreground="blue"
        )
        self.result_label.pack()
    
    def create_history_section(self):
        # History Frame
        history_frame = ttk.LabelFrame(self.main_frame, text="Calculation History", padding=10)
        history_frame.pack(expand=True, fill=tk.BOTH, pady=5)
        
        # History Listbox with Scrollbar
        self.history_list = tk.Listbox(
            history_frame, 
            width=40, 
            height=6,  # Reduced height to make room for buttons
            font=("Courier New", 12),
            bg="white",
            relief=tk.FLAT
        )
        self.history_list.pack(expand=True, fill=tk.BOTH, side=tk.LEFT)
        
        scrollbar = ttk.Scrollbar(
            history_frame, 
            orient=tk.VERTICAL, 
            command=self.history_list.yview
        )
        scrollbar.pack(fill=tk.Y, side=tk.RIGHT)
        self.history_list.config(yscrollcommand=scrollbar.set)
        
        # History Controls - Now with more prominent buttons
        controls_frame = ttk.Frame(self.main_frame)
        controls_frame.pack(fill=tk.X, pady=(0,5))
        
        clear_btn = ttk.Button(
            controls_frame, 
            text="🗑️ Clear History", 
            command=self.clear_history,
            style="Accent.TButton",
            width=15
        )
        clear_btn.pack(side=tk.LEFT, expand=True, padx=5, ipady=5)
        
        export_btn = ttk.Button(
            controls_frame, 
            text="💾 Export History", 
            command=self.export_history,
            width=15
        )
        export_btn.pack(side=tk.LEFT, expand=True, padx=5, ipady=5)
    
    def setup_menu(self):
        self.menu_bar = tk.Menu(self.root)
        
        # File menu
        file_menu = tk.Menu(self.menu_bar, tearoff=0)
        file_menu.add_command(label="Exit", command=self.on_exit)
        self.menu_bar.add_cascade(label="File", menu=file_menu)
        
        # View menu
        view_menu = tk.Menu(self.menu_bar, tearoff=0)
        for theme_id, theme_data in THEMES.items():
            view_menu.add_radiobutton(
                label=theme_data["name"], 
                variable=tk.StringVar(value=self.current_theme), 
                value=theme_id, 
                command=lambda t=theme_id: self.change_theme(t)
            )
        self.menu_bar.add_cascade(label="View", menu=view_menu)
        
        # Help menu
        help_menu = tk.Menu(self.menu_bar, tearoff=0)
        help_menu.add_command(label="About", command=self.show_about)
        self.menu_bar.add_cascade(label="Help", menu=help_menu)
        
        self.root.config(menu=self.menu_bar)
    
    def apply_theme(self):
        style = ttk.Style()
        try:
            style.theme_use(self.current_theme)
        except:
            style.theme_use("clam")
    
    def change_theme(self, theme_name):
        self.current_theme = theme_name
        self.apply_theme()
        self.save_config()
    
    def calculate(self):
        try:
            operation = self.operator.get()
            expression = ""
            
            if operation in ["√", "log", "sin", "cos", "tan"]:
                # Single operand operations
                num1 = float(self.entry1.get())
                
                if operation == "√":
                    if num1 < 0:
                        raise ValueError("Cannot calculate square root of negative number")
                    result = math.sqrt(num1)
                    expression = f"√({num1}) = {result:.4f}"
                elif operation == "log":
                    if num1 <= 0:
                        raise ValueError("Logarithm is only defined for positive numbers")
                    result = math.log10(num1)
                    expression = f"log10({num1}) = {result:.4f}"
                elif operation == "sin":
                    result = math.sin(math.radians(num1))
                    expression = f"sin({num1}°) = {result:.4f}"
                elif operation == "cos":
                    result = math.cos(math.radians(num1))
                    expression = f"cos({num1}°) = {result:.4f}"
                elif operation == "tan":
                    result = math.tan(math.radians(num1))
                    expression = f"tan({num1}°) = {result:.4f}"
                
            else:
                # Two operand operations
                num1 = float(self.entry1.get())
                num2 = float(self.entry2.get())
                
                if operation == "+":
                    result = num1 + num2
                elif operation == "-":
                    result = num1 - num2
                elif operation == "*":
                    result = num1 * num2
                elif operation == "/":
                    if num2 == 0:
                        raise ZeroDivisionError
                    result = num1 / num2
                elif operation == "x^y":
                    result = num1 ** num2
                
                expression = f"{num1} {operation} {num2} = {result:.4f}"
            
            self.result_label.config(text=f"Result: {result:.4f}")
            
            # Add to history
            self.history.append(expression)
            self.history_list.insert(tk.END, expression)
            self.history_list.yview(tk.END)
            
        except ValueError as ve:
            messagebox.showerror("Input Error", str(ve) if str(ve) else "Please enter valid numeric values.")
        except ZeroDivisionError:
            messagebox.showerror("Math Error", "Division by zero is not allowed!")
    
    def clear_fields(self):
        self.entry1.delete(0, tk.END)
        self.entry2.delete(0, tk.END)
        self.result_label.config(text="Result: ")
        self.entry1.focus()
    
    def clear_history(self):
        self.history_list.delete(0, tk.END)
        self.history = []
        messagebox.showinfo("History Cleared", "Calculation history has been cleared.")
    
    def export_history(self):
        file_path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")]
        )
        if file_path:
            try:
                with open(file_path, "w") as f:
                    for item in self.history:
                        f.write(item + "\n")
                messagebox.showinfo("Success", f"History exported to:\n{file_path}")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to export history: {str(e)}")
    
    def show_about(self):
        about_text = """Enhanced Calculator
Version 2.3
        
Features:
- Basic and scientific operations
- Clear button
- Theme support
- History export"""
        messagebox.showinfo("About", about_text)
    
    def save_history(self):
        with open(HISTORY_FILE, "w") as f:
            json.dump(self.history, f)
    
    def load_history(self):
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, "r") as f:
                try:
                    self.history = json.load(f)
                    for item in self.history:
                        self.history_list.insert(tk.END, item)
                    self.history_list.yview(tk.END)
                except (json.JSONDecodeError, AttributeError):
                    pass
    
    def save_config(self):
        config = {
            "theme": self.current_theme,
            "geometry": self.root.geometry()
        }
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f)
    
    def load_config(self):
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r") as f:
                try:
                    config = json.load(f)
                    self.current_theme = config.get("theme", "clam")
                    self.root.geometry(config.get("geometry", "600x700"))
                except (json.JSONDecodeError, AttributeError):
                    pass
    
    def bind_events(self):
        self.root.bind('<Return>', lambda e: self.calculate())
        self.root.bind('<Escape>', lambda e: self.clear_fields())
        self.root.protocol("WM_DELETE_WINDOW", self.on_exit)
    
    def on_exit(self):
        self.save_history()
        self.save_config()
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = CalculatorApp(root)
    root.mainloop()