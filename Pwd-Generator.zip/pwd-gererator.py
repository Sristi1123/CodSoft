import tkinter as tk
from tkinter import ttk, messagebox
import random
import string
import json
import os
from datetime import datetime

class PasswordGenerator:
    def __init__(self, root):
        self.root = root
        self.root.title("🔒 Advanced Password Generator")
        self.root.geometry("500x600")
        self.root.configure(bg="#f0f4f7")
        self.root.resizable(False, False)
        
        # Load saved passwords if available
        self.saved_passwords = []
        self.load_passwords()
        
        # Password strength indicators
        self.strength_var = tk.StringVar(value="")
        self.strength_color = "#cccccc"
        
        # Configure styles
        self.setup_styles()
        
        # Build UI
        self.setup_ui()
        
        # Bind events
        self.length_var.trace_add('write', self.update_strength_indicator)
        self.letters_var.trace_add('write', self.update_strength_indicator)
        self.digits_var.trace_add('write', self.update_strength_indicator)
        self.symbols_var.trace_add('write', self.update_strength_indicator)
        
    def setup_styles(self):
        style = ttk.Style()
        style.configure('TFrame', background="#f0f4f7")
        style.configure('TLabel', background="#f0f4f7", font=('Arial', 11))
        style.configure('TButton', font=('Arial', 11))
        style.configure('Title.TLabel', font=('Helvetica', 18, 'bold'))
        style.configure('Strength.TLabel', font=('Arial', 10, 'bold'))
        style.configure('History.Treeview', font=('Arial', 10), rowheight=25)
        
    def setup_ui(self):
        # Title
        ttk.Label(self.root, text="Advanced Password Generator", style='Title.TLabel').pack(pady=10)
        
        # Main container frame
        main_frame = ttk.Frame(self.root)
        main_frame.pack(pady=10, padx=20, fill='x')
        
        # Password length
        length_frame = ttk.Frame(main_frame)
        length_frame.pack(fill='x', pady=5)
        ttk.Label(length_frame, text="Password Length:").pack(side='left')
        self.length_var = tk.StringVar(value="16")
        length_entry = ttk.Entry(length_frame, textvariable=self.length_var, width=5)
        length_entry.pack(side='left', padx=5)
        self.length_slider = ttk.Scale(length_frame, from_=4, to=64, variable=self.length_var, 
                                      command=lambda v: self.length_var.set(str(int(float(v)))))
        self.length_slider.pack(side='left', fill='x', expand=True)
        
        # Character options
        options_frame = ttk.LabelFrame(main_frame, text="Character Types", padding=10)
        options_frame.pack(fill='x', pady=10)
        
        self.letters_var = tk.BooleanVar(value=True)
        self.digits_var = tk.BooleanVar(value=True)
        self.symbols_var = tk.BooleanVar(value=True)
        
        ttk.Checkbutton(options_frame, text="Uppercase/Lowercase Letters (A-Z, a-z)", 
                        variable=self.letters_var).pack(anchor='w')
        ttk.Checkbutton(options_frame, text="Digits (0-9)", 
                        variable=self.digits_var).pack(anchor='w')
        ttk.Checkbutton(options_frame, text="Special Symbols (!@#$%^&*)", 
                        variable=self.symbols_var).pack(anchor='w')
        
        # Strength indicator
        strength_frame = ttk.Frame(main_frame)
        strength_frame.pack(fill='x', pady=5)
        ttk.Label(strength_frame, text="Strength:").pack(side='left')
        self.strength_label = ttk.Label(strength_frame, textvariable=self.strength_var, 
                                       style='Strength.TLabel', foreground=self.strength_color)
        self.strength_label.pack(side='left', padx=5)
        
        # Generate button
        ttk.Button(main_frame, text="Generate Secure Password", 
                  command=self.generate_password).pack(pady=10, fill='x')
        
        # Result display
        self.result_var = tk.StringVar()
        result_entry = ttk.Entry(main_frame, textvariable=self.result_var, 
                               font=('Arial', 12), justify='center', state='readonly')
        result_entry.pack(fill='x', pady=5)
        
        # Action buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill='x', pady=5)
        
        ttk.Button(button_frame, text="Copy to Clipboard", 
                  command=self.copy_to_clipboard).pack(side='left', expand=True)
        ttk.Button(button_frame, text="Save Password", 
                  command=self.save_password).pack(side='left', expand=True)
        
        # Password history
        history_frame = ttk.LabelFrame(self.root, text="Password History", padding=10)
        history_frame.pack(pady=10, padx=20, fill='both', expand=True)
        
        self.history_tree = ttk.Treeview(history_frame, columns=('password', 'date'), 
                                        show='headings', style='History.Treeview')
        self.history_tree.heading('password', text='Password')
        self.history_tree.heading('date', text='Date Generated')
        self.history_tree.column('password', width=200)
        self.history_tree.column('date', width=150)
        self.history_tree.pack(fill='both', expand=True)
        
        # Populate history
        self.update_history()
        
    def generate_password(self):
        try:
            length = int(self.length_var.get())
            if length < 4:
                messagebox.showwarning("Too Short", "Password should be at least 4 characters long.")
                return
            if length > 64:
                messagebox.showwarning("Too Long", "Password should be no more than 64 characters.")
                return
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter a valid number for password length.")
            return
        
        characters = ""
        if self.letters_var.get():
            characters += string.ascii_letters
        if self.digits_var.get():
            characters += string.digits
        if self.symbols_var.get():
            characters += string.punctuation

        if not characters:
            messagebox.showwarning("Warning", "Select at least one character type!")
            return

        # Ensure at least one character from each selected type is included
        password = []
        if self.letters_var.get():
            password.append(random.choice(string.ascii_letters))
        if self.digits_var.get():
            password.append(random.choice(string.digits))
        if self.symbols_var.get():
            password.append(random.choice(string.punctuation))
        
        # Fill the rest of the password
        remaining_length = length - len(password)
        password.extend(random.choice(characters) for _ in range(remaining_length))
        
        # Shuffle to avoid predictable patterns
        random.shuffle(password)
        
        self.result_var.set(''.join(password))
        self.update_strength_indicator()
        
    def calculate_entropy(self):
        """Calculate password entropy in bits"""
        if not self.result_var.get():
            return 0
            
        charset_size = 0
        if self.letters_var.get():
            charset_size += len(string.ascii_letters)
        if self.digits_var.get():
            charset_size += len(string.digits)
        if self.symbols_var.get():
            charset_size += len(string.punctuation)
            
        length = len(self.result_var.get())
        return length * (charset_size ** 0.5)  # Simplified entropy calculation
        
    def update_strength_indicator(self, *args):
        try:
            length = int(self.length_var.get()) if self.length_var.get() else 0
        except ValueError:
            length = 0
            
        chars_selected = sum([self.letters_var.get(), self.digits_var.get(), self.symbols_var.get()])
        
        # Simple strength calculation
        if length == 0 or chars_selected == 0:
            strength = 0
        else:
            strength = min(100, length * 2 + chars_selected * 20)
        
        # Update display
        if strength < 30:
            self.strength_var.set("Weak")
            self.strength_color = "#ff4444"
        elif strength < 70:
            self.strength_var.set("Moderate")
            self.strength_color = "#ffbb33"
        else:
            self.strength_var.set("Strong")
            self.strength_color = "#00C851"
            
        self.strength_label.configure(foreground=self.strength_color)
        
    def copy_to_clipboard(self):
        password = self.result_var.get()
        if password:
            try:
                self.root.clipboard_clear()
                self.root.clipboard_append(password)
                messagebox.showinfo("Copied", "Password copied to clipboard!")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to copy to clipboard: {str(e)}")
                
    def save_password(self):
        password = self.result_var.get()
        if not password:
            messagebox.showwarning("No Password", "Generate a password first!")
            return
            
        # Add to saved passwords
        self.saved_passwords.append({
            'password': password,
            'date': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
        
        # Save to file
        self.save_passwords()
        self.update_history()
        messagebox.showinfo("Saved", "Password has been saved to history!")
        
    def save_passwords(self):
        try:
            with open('passwords.json', 'w') as f:
                json.dump(self.saved_passwords, f)
        except Exception as e:
            print(f"Error saving passwords: {e}")
            
    def load_passwords(self):
        if os.path.exists('passwords.json'):
            try:
                with open('passwords.json', 'r') as f:
                    self.saved_passwords = json.load(f)
            except Exception as e:
                print(f"Error loading passwords: {e}")
                
    def update_history(self):
        # Clear current items
        for item in self.history_tree.get_children():
            self.history_tree.delete(item)
            
        # Add saved passwords (show most recent first)
        for pw in reversed(self.saved_passwords):
            self.history_tree.insert('', 'end', values=(pw['password'], pw['date']))

if __name__ == "__main__":
    root = tk.Tk()
    app = PasswordGenerator(root)
    root.mainloop()