import tkinter as tk
from tkinter import ttk, messagebox
import json
import os
import re
from datetime import datetime

# Constants
DATA_FILE = "contacts_data.json"
CATEGORIES = ["Family", "Friends", "Relatives", "Emergency", "Others"]
THEMES = {
    "light": {
        "bg": "#f5f5f5", "fg": "#333333", "entry_bg": "white", "button_bg": "#e1e5ea",
        "tree_bg": "white", "tree_fg": "black", "tree_heading": "#e1e5ea"
    },
    "dark": {
        "bg": "#2d2d2d", "fg": "#ffffff", "entry_bg": "#3d3d3d", "button_bg": "#4d4d4d",
        "tree_bg": "#1e1e1e", "tree_fg": "white", "tree_heading": "#3d3d3d"
    }
}

# Validation functions
def is_valid_phone(phone):
    return re.fullmatch(r"[1-9]\d{9}", phone) is not None

def is_valid_email(email):
    return re.fullmatch(r"[^@]+@[^@]+\.[^@]+", email) is not None

def is_valid_date(date_str):
    if not date_str or date_str == "Not set":
        return True
    try:
        datetime.strptime(date_str, "%d-%b")
        return True
    except ValueError:
        return False

class ContactBook:
    def __init__(self, root):
        self.root = root
        self.root.title("📔 Organized Contact Book")
        self.root.geometry("1000x700")
        self.current_theme = "light"
        self.editing_id = None
        self.editing_category = None
        
        self.contacts = self.load_contacts()
        self.setup_theme()
        self.setup_widgets()
        self.apply_theme()
        
    def load_contacts(self):
        if os.path.exists(DATA_FILE):
            try:
                with open(DATA_FILE, "r") as f:
                    data = json.load(f)
                    for cat in CATEGORIES:
                        if cat not in data:
                            data[cat] = []
                        for contact in data[cat]:
                            if "Birthday" not in contact:
                                contact["Birthday"] = "Not set"
                    return data
            except (json.JSONDecodeError, KeyError):
                return {cat: [] for cat in CATEGORIES}
        return {cat: [] for cat in CATEGORIES}
        
    def save_contacts(self):
        try:
            with open(DATA_FILE, "w") as f:
                json.dump(self.contacts, f, indent=2)
            return True
        except Exception as e:
            messagebox.showerror("Save Error", f"Failed to save contacts: {str(e)}")
            return False
        
    def setup_theme(self):
        self.style = ttk.Style()
        self.style.theme_use("clam")
        
    def setup_widgets(self):
        # Header
        self.header_frame = ttk.Frame(self.root)
        self.header_frame.pack(pady=10, fill="x")
        
        self.theme_btn = ttk.Button(self.header_frame, text="🌙", command=self.toggle_theme, width=3)
        self.theme_btn.pack(side="right", padx=10)
        
        # Search
        self.search_frame = ttk.Frame(self.root)
        self.search_frame.pack(fill="x", padx=10, pady=5)
        
        self.search_entry = ttk.Entry(self.search_frame, width=40)
        self.search_entry.pack(side="left", padx=5)
        
        ttk.Button(self.search_frame, text="🔍 Search", command=self.search_contact).pack(side="left")
        
        # Input fields
        self.input_frame = ttk.Frame(self.root)
        self.input_frame.pack(fill="x", padx=10, pady=10)
        
        fields = ["Name", "Phone", "Email", "Address", "Birthday (DD-MMM)", "Category"]
        self.entries = {}
        
        for i, field in enumerate(fields[:-1]):
            ttk.Label(self.input_frame, text=field).grid(row=0, column=i, padx=5)
            entry = ttk.Entry(self.input_frame)
            entry.grid(row=1, column=i, padx=5)
            self.entries[field.split()[0].lower()] = entry
            
            if field == "Address":
                entry.config(width=30)
        
        # Category dropdown
        ttk.Label(self.input_frame, text=fields[-1]).grid(row=0, column=len(fields)-1, padx=5)
        self.category_var = tk.StringVar(value=CATEGORIES[0])
        self.category_menu = ttk.Combobox(self.input_frame, textvariable=self.category_var, 
                                        values=CATEGORIES, state="readonly")
        self.category_menu.grid(row=1, column=len(fields)-1, padx=5)
        
        # Action buttons
        self.btn_frame = ttk.Frame(self.root)
        self.btn_frame.pack(pady=5)
        
        self.add_btn = ttk.Button(self.btn_frame, text="➕ Add", command=self.add_update_contact)
        self.add_btn.grid(row=0, column=0, padx=5)
        
        ttk.Button(self.btn_frame, text="✏️ Edit", command=self.edit_contact).grid(row=0, column=1, padx=5)
        ttk.Button(self.btn_frame, text="❌ Delete", command=self.delete_selected).grid(row=0, column=2, padx=5)
        ttk.Button(self.btn_frame, text="🧹 Clear", command=self.clear_inputs).grid(row=0, column=3, padx=5)
        
        # Tabs
        self.tab_control = ttk.Notebook(self.root)
        self.tab_control.pack(expand=True, fill="both", padx=10, pady=10)
        
        self.tables = {}
        self.tabs = {}
        
        for cat in CATEGORIES:
            tab = ttk.Frame(self.tab_control)
            self.tab_control.add(tab, text=cat)
            self.tabs[cat] = tab
            
            tree_frame = ttk.Frame(tab)
            tree_frame.pack(fill="both", expand=True)
            
            columns = ("Name", "Phone", "Email", "Address", "Birthday")
            tree = ttk.Treeview(tree_frame, columns=columns, show="headings", selectmode="extended")
            
            col_widths = {"Name": 150, "Phone": 120, "Email": 200, "Address": 250, "Birthday": 100}
            for col in columns:
                tree.heading(col, text=col)
                tree.column(col, width=col_widths[col], anchor="w")
            
            scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
            tree.configure(yscrollcommand=scrollbar.set)
            
            tree.pack(side="left", fill="both", expand=True)
            scrollbar.pack(side="right", fill="y")
            
            tree.bind("<Double-1>", lambda e: self.edit_contact())
            
            self.tables[cat] = tree
            self.update_table(cat)
    
    def apply_theme(self):
        theme = THEMES[self.current_theme]
        self.root.config(bg=theme["bg"])
        for widget in [self.header_frame, self.search_frame, self.input_frame, self.btn_frame]:
            widget.config(style="TFrame")
        
        self.style.configure(".", background=theme["bg"], foreground=theme["fg"])
        self.style.configure("TFrame", background=theme["bg"])
        self.style.configure("TLabel", background=theme["bg"], foreground=theme["fg"])
        self.style.configure("TButton", background=theme["button_bg"], foreground=theme["fg"])
        self.style.configure("TEntry", fieldbackground=theme["entry_bg"], foreground=theme["fg"])
        
        self.style.configure("Treeview", 
                           background=theme["tree_bg"],
                           foreground=theme["tree_fg"],
                           fieldbackground=theme["tree_bg"])
        self.style.configure("Treeview.Heading", 
                           background=theme["tree_heading"],
                           foreground=theme["fg"])
        
        self.theme_btn.config(text="🌙" if self.current_theme == "light" else "☀️")
    
    def toggle_theme(self):
        self.current_theme = "dark" if self.current_theme == "light" else "light"
        self.apply_theme()
    
    def add_update_contact(self):
        name = self.entries["name"].get().strip()
        phone = self.entries["phone"].get().strip()
        email = self.entries["email"].get().strip()
        address = self.entries["address"].get().strip()
        birthday = self.entries["birthday"].get().strip()
        category = self.category_var.get()
        
        # Validation
        if not all([name, phone, email, address]):
            messagebox.showwarning("Missing Info", "Name, Phone, Email and Address are required.")
            return
        
        if not is_valid_phone(phone):
            messagebox.showerror("Invalid Phone", "Phone must be 10 digits starting with 1-9.")
            return
        
        if not is_valid_email(email):
            messagebox.showerror("Invalid Email", "Please enter a valid email address.")
            return
        
        if birthday and not is_valid_date(birthday):
            messagebox.showerror("Invalid Birthday", "Birthday must be in DD-MMM format (e.g., 01-Jan) or empty.")
            return
        
        # Check for duplicate phone (except when editing the same contact)
        for cat in self.contacts:
            for contact in self.contacts[cat]:
                if contact["Phone"] == phone:
                    if not self.editing_id or (self.editing_id and phone != self.editing_id):
                        messagebox.showerror("Duplicate", "This phone number already exists!")
                        return
        
        new_contact = {
            "Name": name,
            "Phone": phone,
            "Email": email,
            "Address": address,
            "Birthday": birthday if birthday else "Not set"
        }
        
        if self.editing_id:
            # Update existing contact
            if self.editing_category != category:
                # Remove from old category
                self.contacts[self.editing_category] = [c for c in self.contacts[self.editing_category] 
                                                      if c["Phone"] != self.editing_id]
                # Add to new category
                self.contacts[category].append(new_contact)
            else:
                # Update in same category
                for i, contact in enumerate(self.contacts[category]):
                    if contact["Phone"] == self.editing_id:
                        self.contacts[category][i] = new_contact
                        break
            
            messagebox.showinfo("Updated", "Contact updated successfully!")
            self.editing_id = None
            self.editing_category = None
            self.add_btn.config(text="➕ Add")
        else:
            # Add new contact
            self.contacts[category].append(new_contact)
            messagebox.showinfo("Added", "Contact added successfully!")
        
        if self.save_contacts():
            self.update_table(category)
            if self.editing_category and self.editing_category != category:
                self.update_table(self.editing_category)
            self.clear_inputs()
    
    def edit_contact(self):
        current_tab = self.tab_control.select()
        current_tab_text = self.tab_control.tab(current_tab, "text")
        
        table = self.tables[current_tab_text]
        selected = table.selection()
        
        if not selected:
            messagebox.showwarning("No Selection", "Please select a contact to edit.")
            return
        
        item = selected[0]
        values = table.item(item)["values"]
        
        self.editing_id = values[1]
        self.editing_category = current_tab_text
        
        self.entries["name"].delete(0, tk.END)
        self.entries["name"].insert(0, values[0])
        
        self.entries["phone"].delete(0, tk.END)
        self.entries["phone"].insert(0, values[1])
        
        self.entries["email"].delete(0, tk.END)
        self.entries["email"].insert(0, values[2])
        
        self.entries["address"].delete(0, tk.END)
        self.entries["address"].insert(0, values[3])
        
        self.entries["birthday"].delete(0, tk.END)
        birthday = values[4] if len(values) > 4 else ""
        self.entries["birthday"].insert(0, birthday if birthday != "Not set" else "")
        
        self.category_var.set(current_tab_text)
        self.add_btn.config(text="🔄 Update")
    
    def delete_selected(self):
        current_tab = self.tab_control.select()
        current_tab_text = self.tab_control.tab(current_tab, "text")
        
        table = self.tables[current_tab_text]
        selected = table.selection()
        
        if not selected:
            messagebox.showwarning("No Selection", "Please select contacts to delete.")
            return
        
        confirm = messagebox.askyesno("Confirm Delete", f"Delete {len(selected)} selected contacts?")
        if not confirm:
            return
        
        phones_to_delete = [table.item(item)["values"][1] for item in selected]
        
        self.contacts[current_tab_text] = [
            c for c in self.contacts[current_tab_text] 
            if c["Phone"] not in phones_to_delete
        ]
        
        for item in selected:
            table.delete(item)
        
        if self.save_contacts():
            messagebox.showinfo("Deleted", f"Deleted {len(selected)} contacts.")
    
    def clear_inputs(self):
        for entry in self.entries.values():
            entry.delete(0, tk.END)
        self.category_var.set(CATEGORIES[0])
        self.editing_id = None
        self.editing_category = None
        self.add_btn.config(text="➕ Add")
    
    def update_table(self, category):
        table = self.tables[category]
        table.delete(*table.get_children())
        
        for contact in self.contacts[category]:
            table.insert("", tk.END, values=(
                contact["Name"],
                contact["Phone"],
                contact["Email"],
                contact["Address"],
                contact.get("Birthday", "Not set")
            ))
    
    def search_contact(self):
        query = self.search_entry.get().strip().lower()
        found_any = False
        
        if not query:
            messagebox.showwarning("Empty Search", "Please enter a search term.")
            return
        
        for cat in CATEGORIES:
            table = self.tables[cat]
            table.selection_remove(table.selection())
            
            for child in table.get_children():
                values = [str(v).lower() for v in table.item(child)["values"]]
                
                if (query in values[0] or query in values[1] or query in values[2]):
                    found_any = True
                    self.tab_control.select(self.tabs[cat])
                    table.selection_add(child)
                    table.focus(child)
                    table.see(child)
        
        if not found_any:
            messagebox.showinfo("Not Found", "No matching contacts found.")

if __name__ == "__main__":
    root = tk.Tk()
    app = ContactBook(root)
    root.mainloop()